from django.contrib import admin
from .models import Doctor, Manufacturar

admin.site.register(Doctor)
admin.site.register(Manufacturar)
